// Footer.js
import React from "react";

function Footer() {
    return <footer>© 2024 Movie Reviews</footer>;
}


export default Footer;
