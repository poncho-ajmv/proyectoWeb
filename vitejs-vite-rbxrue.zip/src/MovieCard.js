import React, { useState, useEffect } from 'react';

function MovieCard({ movie }) {
  return (
    <div className="max-w-sm rounded overflow-hidden shadow-lg">
      <img className="w-full" src={movie.poster} alt={movie.title} />
      <div className="px-6 py-4">
        <div className="font-bold text-xl mb-2">{movie.title}</div>
        <p className="text-zinc-700 text-base">
          {movie.category}
        </p>
      </div>
      <div className="px-6 pt-4 pb-2">
        <span className={`inline-block bg-${movie.rating >= 50 ? 'green' : 'red'}-200 rounded-full px-3 py-1 text-sm font-semibold text-zinc-700 mr-2 mb-2`}>
          {movie.rating}%
        </span>
      </div>
    </div>
  );
}

export default function Widget() {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    // Hacer la solicitud a la API para obtener las películas
    fetch('url_de_tu_api')
      .then(response => response.json())
      .then(data => setMovies(data))
      .catch(error => console.error('Error al obtener películas:', error));
  }, []); // Se ejecuta solo una vez al montar el componente

  return (
    <div className="flex">
      {movies.map((movie, index) => (
        <MovieCard key={index} movie={movie} />
      ))}
    </div>
  );
}
