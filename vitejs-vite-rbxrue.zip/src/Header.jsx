import React from "react";
import SearchBar from "./SearchBar";
import Dropdown from "./Dropdown"; // Importa tu componente Dropdown personalizado
import "./Menu.css";

function Header({ setMovies }) {
  return (
    <header>
      <div className="menu">
        <ul>
          <li>
            <img
              src="http://imgfz.com/i/OehyQAa.png"
              alt="Logo"
              className="logo"
            />
          </li>
          <li>
            <a href="#">Home</a>
          </li>
          <li>
            <Dropdown title="Categorías">
              <ul>
                <li>
                  <a href="#">Drama</a>
                </li>
                <li>
                  <a href="#">Comedia</a>
                </li>
                <li>
                  <a href="#">Ciencia Ficción</a>
                </li>
                <li>
                  <a href="#">Infantil</a>
                </li>
                <li>
                  <a href="#">Estrenos</a>
                </li>
              </ul>
            </Dropdown>
          </li>
          <li>
            <Dropdown title="Idioma">
              <ul>
                <li>
                  <a href="#">Español</a>
                </li>
                <li>
                  <a href="#">Inglés</a>
                </li>
                <li>
                  <a href="#">Francés</a>
                </li>
                {/* Agrega más idiomas según sea necesario */}
              </ul>
            </Dropdown>
          </li>
          <li className="search-bar-container">
            <SearchBar setMovies={setMovies} />
          </li>
        </ul>
      </div>
      <h1>Movie Reviews</h1>
    </header>
  );
}

export default Header;
